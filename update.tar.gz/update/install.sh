#########################################################################
# File Name: install.sh
# Author: zhx
# mail: 2536153564@qq.com
# Created Time: 2018年03月14日 星期三 12时53分20秒
#########################################################################
#!/bin/bash
mv /tmp/update/boxversion /home/bin/boxversion
mv /tmp/update/sctrl /home/sbin/sctrl
mv /tmp/update/disk /home/sbin/disk

/etc/init.d/sctrl stop
/etc/init.d/sctrl start
/etc/init.d/diskmount stop
/etc/init.d/diskmount start

mv /tmp/update/box /home/sbin/box

killall box
/home/sbin/box &
